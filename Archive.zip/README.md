# Trade-Ninja

A free online simulator that allows you to purchase shares and track their performance with realtime quotes.


# APIs
    - Alpha Vantage

# Front End
    - jQuery
    - Bootstrap
    - handlebars

# Back End
    - mySQL
    - express
    - express-handlebars
    - express-sessions
    - bcrypt
    - axios
    - nodemailer


# Demo

Try it out www.mytradeninja.com 